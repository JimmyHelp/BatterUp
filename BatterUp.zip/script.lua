-- Example Avatar --

--hide vanilla model
vanilla_model.PLAYER:setVisible(false)

local batterUp = require("BatterUp") -- require the script and save it to batterUp in order to use it

local anim = animations.model

local chained = { -- put animations in a table
	anim.chain1,
	anim.chain2,
	anim.chain3,
}

local randos = {
	anim.rand1,
	anim.rand2,
	anim.rand3,
	anim.rand4
}

batterUp:addChainedSwings(chained,"right","wooden_sword","attack",true,20) -- fill in arguments

batterUp:addRandomSwings(randos,"left",nil,nil,true)

function events.item_render(item)
	if item.id=="minecraft:wooden_sword" then
		return models.model.ItemBat
	end
end